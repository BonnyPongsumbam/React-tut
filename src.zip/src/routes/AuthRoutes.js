import React from 'react'
import { Login } from '../login/Login'

const AuthRoutes = {
    path: "/",
    element: <Login />

  
}

export default AuthRoutes






        
        // { path: "/", element: <Navigate to="login" /> },
