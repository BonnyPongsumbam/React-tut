import './App.css';
import React from 'react';
import Route from "./routes"


export const App=()=> {
 
  return (
    <div >
  <Route/>
  
    </div>
  );
}

